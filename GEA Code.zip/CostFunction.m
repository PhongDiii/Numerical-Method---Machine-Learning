

function z=CostFunction(x)

%Sphere
z=sum(x.^2,2);

end

