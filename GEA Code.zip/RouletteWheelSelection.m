
function i=RouletteWheelSelection(p)

    c=cumsum(p);
    r=rand();
    i=find(r<=c,1,'first');

end