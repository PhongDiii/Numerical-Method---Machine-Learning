%--------------------------------------------------------------------------
% AHA code v1.0.
% Developed in MATLAB R2016b
% The code is based on the following papers:
% W. Zhao, L. Wang and S. Mirjalili, Artificial hummingbird algorithm: A
% new bio-inspired optimizer with its engineering applications, Computer
% Methods in Applied Mechanics and Engineering (2021) 114194, https:
% //doi.org/10.1016/j.cma.2021.114194.
%--------------------------------------------------------------------------

clc;
clear;
MaxIteration=1000;
PopSize=50;
FunIndex=1;
[BestX,BestF,HisBestF]=AHA(FunIndex,MaxIteration,PopSize);

display(['FunIndex=', num2str(FunIndex)]);
display(['The best fitness is: ', num2str(BestF)]);
%display(['The best solution is: ', num2str(BestX)]);
if BestF>0
    semilogy(HisBestF,'r','LineWidth',2);
else
    plot(HisBestF,'r','LineWidth',2);
end
xlabel('Iterations');
ylabel('Fitness');
title(['F',num2str(FunIndex)]);










