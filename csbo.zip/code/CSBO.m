

%%%%%  Circulatory System Based Optimization (CSBO): an expert multilevel biologically
%%%%%                             inspired meta-heuristic algorithm
%%%%%                 ENGINEERING APPLICATIONS OF COMPUTATIONAL FLUID MECHANICS
%%%%%                       https://doi.org/10.1080/19942060.2022.2098826

clc;
clear all;


%% Problem Definition

CostFunction=@(x) ShiftedRosenbrock(x);

nVar=30;                 % Number of Decision Variables

VarSize=[1 nVar];       % Decision Variables Matrix Size

VarMin=-100;             % Decision Variables Lower Bound
VarMax= -VarMin;         % Decision Variables Upper Bound




%% CSBO Parameters

MaxIt = 300000;    % Maximum Number of Iterations

nPop = 45;         % Population Size

NR=nPop/3;         %numbers of the weakest population enter the pulmonary circulation
%% Initialization


empty_plant.Position = [];
empty_plant.Cost = [];

pop = repmat(empty_plant, nPop, 1);    % Initial Population Array
% Initialize Best Solution Ever Found
BestSol.Cost=inf;

for i = 1:numel(pop)
    
    % Initialize Position
    pop(i).Position = unifrnd(VarMin, VarMax, VarSize);
    
    % Evaluation
    pop(i).Cost = CostFunction(pop(i).Position);
    
    sigma1(i,:) =rand(VarSize);
    if pop(i).Cost<=BestSol.Cost
        BestSol.Position=pop(i).Position;
        BestSol.Cost=pop(i).Cost;
    end
    BestCost1(i)=BestSol.Cost;
end



%% CSBO Main Loop

it=nPop;
% % for it=1:MaxIt
while it<=MaxIt
    
    
    % Get Best and Worst Cost Values
    Costs = [pop.Cost];
    BestCost = min(Costs);
    WorstCost = max(Costs);
    
    
    for i = 1:numel(pop)
        
        newsol = empty_plant;
        Pos(1,:) = 0*unifrnd(VarMin, VarMax, VarSize);
        
        
        A=randperm(nPop);
        A(A==i)=[];
        a1=A(1);
        a2=A(2);
        a3=A(3);
        a4=A(4);
        a5=A(5);
        Costs = [pop.Cost];
        BestCost = min(Costs);
        WorstCost = max(Costs);
        AA1=((pop(a2).Cost-pop(a3).Cost)/abs(pop(a3).Cost-pop(a2).Cost));
        if (pop(a2).Cost-pop(a3).Cost)==0
            AA1=1;
        end
        AA2=((pop(a1).Cost-pop(i).Cost)/abs(pop(a1).Cost-pop(i).Cost));
        if (pop(a1).Cost-pop(i).Cost)==0
            AA2=1;
        end
        %%%Movement of blood mass in the veins
        Pos= pop(i).Position+(AA2*sigma1(i)).*(pop(i).Position-pop(a1).Position)+(AA1*sigma1(i)).*(pop(a3).Position-pop(a2).Position);
        
        
        newsol.Position =Pos;
        
        
        newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
        
        % Evaluate
        newsol.Cost = CostFunction(newsol.Position);
        
        if newsol.Cost<pop(i).Cost
            pop(i)=newsol;
            if pop(i).Cost<=BestSol.Cost
                BestSol=pop(i);
            end
            
        end
        it=it+1;
        BestCost1(it)=BestSol.Cost;
        
        
    end
    
    
    % Sort Population
    [~, SortOrder]=sort([pop.Cost]);
     pop = pop(SortOrder);
    
    %Population or blood mass flow in Systematic Circulation
    i=0;
    newpop1 = [];
    for i = 1:(numel(pop)-NR)
        Pos1(1,:) = 0*unifrnd(VarMin, VarMax, VarSize);
        Costs = [pop.Cost];
        BestCost = min(Costs);
        WorstCost = max(Costs);
        ratioi= (pop(i).Cost - WorstCost)/(BestCost - WorstCost);
        newsol = empty_plant;
        
        A=randperm(nPop);
        A(A==i)=[];
        a1=A(1);
        a2=A(2);
        a3=A(3);
        sigma1(i,:)=ratioi;
        newsol.Position =pop(a1).Position+(sigma1(i)).*(pop(a3).Position-pop(a2).Position);
        see=pop(i).Position;
        
        for j =1:nVar
            if rand>0.9
                Pos1(1,j) =newsol.Position(1,j);
            else
                Pos1(1,j)= see(1,j);
            end
        end
        newsol.Position =Pos1;
        % Apply Lower/Upper Bounds
        newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
        
        
        % Evaluate
        newsol.Cost = CostFunction(newsol.Position);
        if newsol.Cost<pop(i).Cost
            pop(i)=newsol;
            if pop(i).Cost<=BestSol.Cost
                BestSol=pop(i);
            end
        end
        it=it+1;
        BestCost1(it)=BestSol.Cost;
        
    end
    % Population or blood mass flow in Pulmonary Circulation
    newpop = [];
    i=0;
    
    for i = ((numel(pop)-NR)+1):numel(pop)
        newsol = empty_plant;
        
        
        newsol.Position =pop(i).Position + (randn/it) .* randc(1,nVar);
        
        % Apply Lower/Upper Bounds
        newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
        
        % Evaluate
        newsol.Cost = CostFunction(newsol.Position);
        if newsol.Cost<pop(i).Cost
            pop(i)=newsol;
            if pop(i).Cost<=BestSol.Cost
                BestSol=pop(i);
            end
        end
        it=it+1;
        BestCost1(it)=BestSol.Cost;
        
        sigma1(i,:)=rand(VarSize);
    end
    
    
    
    
    % Display Iteration Information
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost1(it))]);
    
end



BestSol.Position

plot(log(BestCost1),'b','LineWidth',2); hold on

